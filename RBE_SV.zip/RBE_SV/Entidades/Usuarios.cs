﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RBE_SV.Entidades
{
    class Usuarios
    {
        public string Usuario { get; set; }
        public string Contra { get; set;}
    }
}
