﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RBE_SV.Entidades
{
    class Response
    {
        public int Codigo { get; set; }
        public string Mensaje { get; set; }
        public object Data { get; set; }
    }
}
